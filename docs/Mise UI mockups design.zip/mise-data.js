window.MiseData = (function () {
  const T = {
    en: {
      appSub: 'Front of House', floorplan: 'Floor plan', timeline: 'Timeline', reservations: 'Reservations', tables: 'Tables & sections',
      editor: 'Floor plan editor', hours: 'Service hours', staff: 'Staff', conflicts: 'Conflicts', conflictsTitle: 'Sync conflicts', devices: 'Devices',
      managerHdr: 'Manager', newRes: '+ New reservation', onlineSynced: 'Online · synced', offline: 'Offline', pending: 'pending',
      offlineTitle: 'No connection.', offlineBody: 'Keep working — changes are saved on this tablet and sync automatically when the connection returns.',
      lastSynced: 'Last synced', signOut: 'Sign out', webOnly: 'Staff and device management are on the website.',
      Available: 'Available', Reserved: 'Reserved', Occupied: 'Occupied', NeedsCleaning: 'Needs cleaning', Blocked: 'Blocked',
      Confirmed: 'Confirmed', Seated: 'Seated', Completed: 'Completed', NoShow: 'No-show', Cancelled: 'Cancelled',
      synced: 'Synced', pendingSync: 'Pending sync', conflict: 'Sync conflict',
      all: 'All', nextArrivals: 'Next arrivals', unassigned: 'Unassigned', dragHint: 'Drag a guest onto a table, or a table to move a party', seats: 'seats',
      lunch: 'Lunch', dinner: 'Dinner', search: 'Search name or phone…', noResults: 'No reservations found', noResultsSub: 'Try another day or search term.',
      today: 'Today', tomorrow: 'Tomorrow',
      phone: 'Phone', party: 'Party', time: 'Time', duration: 'Duration', table: 'Table', notes: 'Notes', history: 'History',
      edit: 'Edit', cancelRes: 'Cancel', noShow: 'No-show', seat: 'Mark seated', needTable: 'Assign a table before seating this party.',
      newResTitle: 'New reservation', editResTitle: 'Edit reservation', name: 'Customer name', date: 'Date', notesPh: 'Allergies, occasion, seating preference…',
      save: 'Save changes', create: 'Save reservation', close: 'Close', discard: 'Cancel', onFile: 'On file', use: 'Use',
      partyErr: 'Party size is required and must be more than 0.', capWarn: '{t} seats up to {n}. Pick a larger table or a table group.',
      lastChanged: 'Last changed by {who} · {when}', min: 'min',
      cancelTitle: 'Cancel this reservation?', noShowTitle: 'Mark as no-show?', reason: 'Reason',
      reasonsCancel: ['Guest called to cancel', 'Duplicate booking', 'Restaurant closed', 'Other'],
      reasonsNoShow: ['Did not arrive, no answer by phone', 'Arrived too late to seat', 'Other'],
      freesTable: 'Table {t} becomes available again unless another reservation holds it.', keep: 'Keep reservation',
      confirmCancel: 'Cancel reservation', confirmNoShow: 'Mark no-show', auditNote: 'Recorded in the history under your name.',
      now: 'Now', tablesSub: 'Changes apply to the live floor plan on every device.', editLayout: 'Edit layout', addSection: '+ Add section',
      addTable: '+ Add table', colTable: 'Table', colCap: 'Capacity', colComb: 'Combinable', colState: 'State', yes: 'Yes', no: 'No',
      active: 'Active', inactive: 'Inactive', deactivate: 'Deactivate', activate: 'Activate', hasActive: 'Has an active reservation',
      groups: 'Table groups', groupsSub: 'When a party is larger than one table, it can be seated on a group. Capacity is the sum of its tables.',
      newGroup: '+ New group', groupTitle: 'New table group', groupPick: 'Select tables',
      groupRule: 'Only active, combinable tables that aren’t already in a group.', combined: 'Combined capacity', createGroup: 'Create group',
      notComb: 'not combinable', inGroup: 'in', groupNeed: 'Pick at least two tables.',
      editorSub: 'Drag tables to match the room. The saved layout is used on every device.', unsaved: 'Unsaved changes', saveLayout: 'Save layout',
      discardChanges: 'Discard', section: 'Section', minSeats: 'Min seats', maxSeats: 'Max seats', shape: 'Shape', round: 'Round', rect: 'Rectangle',
      position: 'Position', selectTable: 'Select a table to edit it.',
      hoursSub: 'Service periods per day. Closed days can’t take reservations.', day: 'Day', closed: 'Closed', open: 'Open', addPeriod: '+ Add',
      exceptions: 'Closures & exceptions', addClosure: '+ Add closure', weekOf: 'Week', noService: '—',
      staffSub: 'Staff sign in on the website with username and password, and on tablets with a personal PIN.', addStaff: '+ Add staff member',
      colName: 'Name', colRole: 'Role', colUser: 'Username', colPin: 'PIN', colLast: 'Last active', FloorStaff: 'Floor staff', Manager: 'Manager',
      pinSet: 'Set', pinNone: 'Not set', pinLocked: 'Locked', clearLock: 'Clear PIN lock', reactivate: 'Reactivate',
      lockNotice: '{name} is locked out of PIN sign-in after 5 failed attempts on {device}.',
      pinResetTitle: 'Clear PIN lock for {name}?',
      pinResetBody: 'Their current PIN is removed. {first} sets a new PIN after signing in to the website with their own password. Managers never see or choose a staff member’s PIN.',
      clearLockBtn: 'Clear lock',
      conflictsSub: 'Offline changes that failed server checks. They stay here until a manager resolves them — nothing is applied or dropped automatically.',
      openLbl: 'Open', resolvedToday: 'Resolved today', submitted: 'Submitted offline', onServer: 'On the server now', detected: 'Detected',
      reassignTo: 'Reassign submitted booking to', reassign: 'Reassign', reject: 'Reject submitted', acceptBoth: 'Accept submitted',
      keepServer: 'Keep server version', applySubmitted: 'Apply submitted change',
      revalidate: 'Only tables that pass capacity and overlap checks are listed.', queueClear: 'Queue clear — no open conflicts',
      devicesSub: 'Deactivating a device blocks new PIN sign-ins as soon as it’s reachable.',
      pairNew: 'To pair a new tablet, open Mise on it and sign in with a manager account.', lastSeen: 'Last seen',
      graceEnds: 'Offline session ends', deactivated: 'Deactivated', online: 'Online', pairedBy: 'Paired by',
      whoIs: 'Who’s signing in?', enterPin: 'Enter your PIN', pinWrong: 'Incorrect PIN. {n} attempts left.', pairedDevice: 'Paired device',
      pickName: 'Tap your name to sign in.', lockedTitle: 'PIN locked',
      lockedBody: 'Too many incorrect attempts on this tablet. Sign in to the Mise website with your password to set a new PIN, or ask a manager.',
      chooseOther: 'Choose someone else',
      revokedTitle: 'This tablet is no longer paired',
      revokedBody: 'A manager deactivated this device. PIN sign-in stays disabled until a manager pairs it again.',
      pairAgain: 'Pair this tablet', pairTitle: 'Pair this tablet', step1: 'Manager sign-in', step2: 'Name device', step3: 'Done',
      pairBody1: 'Only a manager can pair a device. Sign in with your website username and password.',
      username: 'Username', password: 'Password', continue: 'Continue', deviceName: 'Device name',
      deviceNameHint: 'Shown on the sign-in screen and in the device list.', pairBtn: 'Pair device',
      pairedTitle: '{d} is paired', pairedBody: 'Staff can now sign in here with their personal PIN. You can deactivate this tablet at any time from Devices on the website.',
      goPin: 'Go to PIN sign-in', back: 'Back', backOffice: 'Back office', signInTo: 'Sign in to Mise', signIn: 'Sign in',
      changeStatus: 'Change status', current: 'Current', nextRes: 'Next reservation', seatNew: 'New reservation at this table',
      free: 'free', occ: 'occupied', res: 'reserved', guests: 'guests', walkIn: 'Walk-in'
    },
    nl: {
      appSub: 'Zaal', floorplan: 'Zaalplan', timeline: 'Tijdlijn', reservations: 'Reservaties', tables: 'Tafels & zones',
      editor: 'Zaalplan bewerken', hours: 'Openingsuren', staff: 'Personeel', conflicts: 'Conflicten', conflictsTitle: 'Synchronisatieconflicten', devices: 'Toestellen',
      managerHdr: 'Manager', newRes: '+ Nieuwe reservatie', onlineSynced: 'Online · gesynchroniseerd', offline: 'Offline', pending: 'in wachtrij',
      offlineTitle: 'Geen verbinding.', offlineBody: 'Werk gewoon verder — wijzigingen worden op deze tablet bewaard en automatisch gesynchroniseerd zodra de verbinding terug is.',
      lastSynced: 'Laatst gesynchroniseerd', signOut: 'Afmelden', webOnly: 'Personeel en toestellen beheer je op de website.',
      Available: 'Vrij', Reserved: 'Gereserveerd', Occupied: 'Bezet', NeedsCleaning: 'Af te ruimen', Blocked: 'Geblokkeerd',
      Confirmed: 'Bevestigd', Seated: 'Geplaatst', Completed: 'Afgerond', NoShow: 'No-show', Cancelled: 'Geannuleerd',
      synced: 'Gesynchroniseerd', pendingSync: 'Wacht op sync', conflict: 'Syncconflict',
      all: 'Alle', nextArrivals: 'Volgende aankomsten', unassigned: 'Geen tafel', dragHint: 'Sleep een gast naar een tafel, of een tafel om te verhuizen', seats: 'plaatsen',
      lunch: 'Middag', dinner: 'Avond', search: 'Zoek op naam of telefoon…', noResults: 'Geen reservaties gevonden', noResultsSub: 'Probeer een andere dag of zoekterm.',
      today: 'Vandaag', tomorrow: 'Morgen',
      phone: 'Telefoon', party: 'Personen', time: 'Uur', duration: 'Duur', table: 'Tafel', notes: 'Notities', history: 'Geschiedenis',
      edit: 'Bewerken', cancelRes: 'Annuleren', noShow: 'No-show', seat: 'Plaatsen', needTable: 'Wijs eerst een tafel toe om dit gezelschap te plaatsen.',
      newResTitle: 'Nieuwe reservatie', editResTitle: 'Reservatie bewerken', name: 'Naam klant', date: 'Datum', notesPh: 'Allergieën, gelegenheid, plaatsvoorkeur…',
      save: 'Wijzigingen opslaan', create: 'Reservatie opslaan', close: 'Sluiten', discard: 'Annuleren', onFile: 'Gekend', use: 'Gebruik',
      partyErr: 'Aantal personen is verplicht en moet groter zijn dan 0.', capWarn: '{t} heeft maximaal {n} plaatsen. Kies een grotere tafel of een tafelcombinatie.',
      lastChanged: 'Laatst gewijzigd door {who} · {when}', min: 'min',
      cancelTitle: 'Deze reservatie annuleren?', noShowTitle: 'Markeren als no-show?', reason: 'Reden',
      reasonsCancel: ['Klant belde om te annuleren', 'Dubbele boeking', 'Restaurant gesloten', 'Andere'],
      reasonsNoShow: ['Niet komen opdagen, onbereikbaar', 'Te laat om nog te plaatsen', 'Andere'],
      freesTable: 'Tafel {t} komt weer vrij, tenzij een andere reservatie ze vasthoudt.', keep: 'Reservatie behouden',
      confirmCancel: 'Reservatie annuleren', confirmNoShow: 'No-show bevestigen', auditNote: 'Wordt op jouw naam in de geschiedenis bewaard.',
      now: 'Nu', tablesSub: 'Wijzigingen gelden meteen op elk toestel.', editLayout: 'Plan bewerken', addSection: '+ Zone toevoegen',
      addTable: '+ Tafel toevoegen', colTable: 'Tafel', colCap: 'Capaciteit', colComb: 'Combineerbaar', colState: 'Status', yes: 'Ja', no: 'Nee',
      active: 'Actief', inactive: 'Inactief', deactivate: 'Deactiveren', activate: 'Activeren', hasActive: 'Heeft een actieve reservatie',
      groups: 'Tafelcombinaties', groupsSub: 'Is een gezelschap te groot voor één tafel, dan kan het aan een combinatie zitten. De capaciteit is de som van de tafels.',
      newGroup: '+ Nieuwe combinatie', groupTitle: 'Nieuwe tafelcombinatie', groupPick: 'Kies tafels',
      groupRule: 'Enkel actieve, combineerbare tafels die nog niet in een combinatie zitten.', combined: 'Samen', createGroup: 'Combinatie aanmaken',
      notComb: 'niet combineerbaar', inGroup: 'in', groupNeed: 'Kies minstens twee tafels.',
      editorSub: 'Sleep de tafels naar hun plek. Het opgeslagen plan geldt voor elk toestel.', unsaved: 'Niet opgeslagen', saveLayout: 'Plan opslaan',
      discardChanges: 'Verwerpen', section: 'Zone', minSeats: 'Min. plaatsen', maxSeats: 'Max. plaatsen', shape: 'Vorm', round: 'Rond', rect: 'Rechthoek',
      position: 'Positie', selectTable: 'Kies een tafel om ze te bewerken.',
      hoursSub: 'Diensten per dag. Op gesloten dagen kan je niet reserveren.', day: 'Dag', closed: 'Gesloten', open: 'Open', addPeriod: '+ Toevoegen',
      exceptions: 'Sluitingen & uitzonderingen', addClosure: '+ Sluiting toevoegen', weekOf: 'Week', noService: '—',
      staffSub: 'Medewerkers melden zich op de website aan met gebruikersnaam en wachtwoord, en op tablets met een persoonlijke pincode.', addStaff: '+ Medewerker toevoegen',
      colName: 'Naam', colRole: 'Rol', colUser: 'Gebruikersnaam', colPin: 'Pincode', colLast: 'Laatst actief', FloorStaff: 'Zaalpersoneel', Manager: 'Manager',
      pinSet: 'Ingesteld', pinNone: 'Niet ingesteld', pinLocked: 'Geblokkeerd', clearLock: 'Pincode deblokkeren', reactivate: 'Heractiveren',
      lockNotice: '{name} kan zich niet meer met pincode aanmelden na 5 foute pogingen op {device}.',
      pinResetTitle: 'Pincode van {name} deblokkeren?',
      pinResetBody: 'De huidige pincode wordt verwijderd. {first} kiest een nieuwe pincode na aanmelden op de website met het eigen wachtwoord. Managers zien of kiezen nooit de pincode van een medewerker.',
      clearLockBtn: 'Deblokkeren',
      conflictsSub: 'Offline wijzigingen die de servercontrole niet doorstonden. Ze blijven hier tot een manager ze oplost — niets wordt automatisch toegepast of verwijderd.',
      openLbl: 'Open', resolvedToday: 'Vandaag opgelost', submitted: 'Offline ingediend', onServer: 'Nu op de server', detected: 'Gedetecteerd',
      reassignTo: 'Ingediende reservatie verplaatsen naar', reassign: 'Verplaatsen', reject: 'Ingediende weigeren', acceptBoth: 'Ingediende aanvaarden',
      keepServer: 'Serverversie behouden', applySubmitted: 'Ingediende wijziging toepassen',
      revalidate: 'Enkel tafels die de controle op capaciteit en overlap doorstaan.', queueClear: 'Geen openstaande conflicten',
      devicesSub: 'Een gedeactiveerd toestel weigert nieuwe aanmeldingen met pincode zodra het bereikbaar is.',
      pairNew: 'Een nieuwe tablet koppel je door Mise erop te openen en je aan te melden met een manageraccount.', lastSeen: 'Laatst gezien',
      graceEnds: 'Offline sessie verloopt', deactivated: 'Gedeactiveerd', online: 'Online', pairedBy: 'Gekoppeld door',
      whoIs: 'Wie meldt zich aan?', enterPin: 'Geef je pincode in', pinWrong: 'Foute pincode. Nog {n} pogingen.', pairedDevice: 'Gekoppeld toestel',
      pickName: 'Tik op je naam om je aan te melden.', lockedTitle: 'Pincode geblokkeerd',
      lockedBody: 'Te veel foute pogingen op deze tablet. Meld je aan op de Mise-website met je wachtwoord om een nieuwe pincode in te stellen, of vraag het aan een manager.',
      chooseOther: 'Iemand anders kiezen',
      revokedTitle: 'Deze tablet is niet meer gekoppeld',
      revokedBody: 'Een manager heeft dit toestel gedeactiveerd. Aanmelden met pincode blijft uitgeschakeld tot een manager het opnieuw koppelt.',
      pairAgain: 'Tablet koppelen', pairTitle: 'Tablet koppelen', step1: 'Manager aanmelden', step2: 'Toestel benoemen', step3: 'Klaar',
      pairBody1: 'Enkel een manager kan een toestel koppelen. Meld je aan met je gebruikersnaam en wachtwoord van de website.',
      username: 'Gebruikersnaam', password: 'Wachtwoord', continue: 'Verder', deviceName: 'Naam toestel',
      deviceNameHint: 'Zichtbaar op het aanmeldscherm en in de lijst met toestellen.', pairBtn: 'Toestel koppelen',
      pairedTitle: '{d} is gekoppeld', pairedBody: 'Medewerkers kunnen zich hier nu aanmelden met hun persoonlijke pincode. Je kan deze tablet altijd deactiveren via Toestellen op de website.',
      goPin: 'Naar aanmelden met pincode', back: 'Terug', backOffice: 'Backoffice', signInTo: 'Aanmelden bij Mise', signIn: 'Aanmelden',
      changeStatus: 'Status wijzigen', current: 'Huidig', nextRes: 'Volgende reservatie', seatNew: 'Nieuwe reservatie aan deze tafel',
      free: 'vrij', occ: 'bezet', res: 'gereserveerd', guests: 'personen', walkIn: 'Zonder reservatie'
    }
  };
  const DAYS = { en: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], nl: ['ma', 'di', 'wo', 'do', 'vr', 'za', 'zo'] };
  const MON = { en: 'Sep', nl: 'sep' };

  const caps = {
    'Main Room': [2, 2, 4, 4, 4, 6, 2, 4, 4, 6, 8, 4, 4, 4],
    'Patio': [2, 4, 4, 2, 6, 4, 2, 4, 2, 4],
    'Bar': [2, 2, 2, 4, 2, 4]
  };
  const pos = {
    'Main Room': [[10, 14], [24, 14], [38, 14], [52, 14], [66, 14], [83, 16], [8, 42], [8, 66], [45, 42], [64, 42], [45, 70], [88, 50], [68, 84], [88, 84]],
    'Patio': [[12, 24], [30, 18], [50, 24], [70, 18], [88, 26], [15, 62], [35, 70], [55, 62], [75, 70], [90, 72]],
    'Bar': [[20, 74], [40, 74], [60, 74], [80, 74], [30, 46], [66, 46]]
  };
  const prefix = { 'Main Room': 'M', 'Patio': 'P', 'Bar': 'B' };
  const secNames = { en: { 'Main Room': 'Main room', 'Patio': 'Patio', 'Bar': 'Bar' }, nl: { 'Main Room': 'Grote zaal', 'Patio': 'Terras', 'Bar': 'Bar' } };
  const notComb = ['M9', 'M11', 'P5', 'B1', 'B2', 'B3', 'B4', 'B5', 'B6'];

  function reservations() {
    const r = (id, start, dur, name, phone, party, tableId, status, notes, by) => ({ id, start, dur, name, phone, party, tableId, status, notes: notes || '', by: by || 's2' });
    return [
      r('r1', '12:00', 90, 'De Smet, Jonas', '0470 11 22 33', 2, 'P3', 'Completed'),
      r('r2', '12:30', 90, 'Vermeulen, Anke', '0478 22 33 44', 4, 'M4', 'Completed', 'Window seat requested'),
      r('r3', '13:15', 75, 'Bakker, Tom', '0491 33 44 55', 3, 'M2', 'Completed'),
      r('r10', '18:15', 90, 'De Clercq, Marie', '0473 66 77 88', 2, 'P7', 'NoShow'),
      r('r4', '18:00', 120, 'Claes, Sophie', '0479 44 55 66', 6, 'M11', 'Seated', 'Birthday — bringing a cake', 's1'),
      r('r5', '18:30', 90, 'Janssens, Pieter', '0470 55 66 77', 2, 'B2', 'Seated'),
      r('r16', '18:45', 90, 'Goossens, Eva', '0485 10 20 30', 4, 'M5', 'Seated'),
      r('r17', '19:00', 120, 'Jacobs, Tim', '0476 40 50 60', 4, 'P2', 'Seated'),
      r('r6', '19:00', 90, 'Vandenberghe, Elke', '0472 88 99 00', 4, 'M12', 'Confirmed', 'Regular guest', 's1'),
      r('r7', '19:30', 90, 'Willems, Karim', '0498 12 12 12', 5, '', 'Confirmed'),
      r('r8', '19:30', 90, 'Peeters, Lieve', '0470 90 80 70', 4, 'M3', 'Confirmed', 'Nut allergy'),
      r('r9', '19:45', 90, 'Aerts, Wim', '0493 21 43 65', 2, 'P1', 'Confirmed'),
      r('r11', '20:00', 105, 'Coppens, Hanne', '0477 70 71 72', 6, 'M6', 'Confirmed', 'VIP — owner’s guest'),
      r('r12', '20:15', 90, 'Wouters, Lars', '0468 01 02 03', 4, 'M8', 'Confirmed'),
      r('r13', '20:30', 90, 'Mertens, Yves', '0471 99 00 11', 8, '', 'Cancelled', 'Cancelled by phone'),
      r('r14', '20:45', 90, 'Lambrechts, Ine', '0484 55 44 33', 3, '', 'Confirmed', 'Prefers patio'),
      r('r15', '21:00', 90, 'Hermans, Bart', '0495 66 77 88', 2, 'B4', 'Confirmed')
    ];
  }
  const toMin = s => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
  const NOW = toMin('19:04');

  function tables(res) {
    const out = [];
    Object.keys(caps).forEach(section => {
      caps[section].forEach((cap, i) => {
        const id = prefix[section] + (i + 1);
        const [x, y] = pos[section][i];
        let status = 'Available';
        const seated = res.find(r => r.tableId === id && r.status === 'Seated');
        const soon = res.find(r => r.tableId === id && r.status === 'Confirmed' && toMin(r.start) - NOW <= 30);
        if (seated) status = 'Occupied'; else if (soon) status = 'Reserved';
        if (id === 'M9' || id === 'B3') status = 'Blocked';
        if (id === 'M1' || id === 'P4') status = 'NeedsCleaning';
        if (id === 'B1' || id === 'M13') status = 'Occupied';
        out.push({ id, name: id, section, minCap: cap >= 4 ? 2 : 1, maxCap: cap, status, combinable: !notComb.includes(id), isActive: true, round: cap <= 4, x, y });
      });
    });
    return out;
  }
  function staff() {
    const s = (id, name, role, username, pin, last, active) => ({ id, name, role, username, pin, last, active: active !== false });
    return [
      s('s1', 'Sam Verhoeven', 'Manager', 'sverhoeven', 'set', { en: 'Now · website', nl: 'Nu · website' }),
      s('s2', 'Emma Dubois', 'FloorStaff', 'edubois', 'set', { en: 'Now · Host Stand 1', nl: 'Nu · Host Stand 1' }),
      s('s3', 'Noor El Idrissi', 'Manager', 'nelidrissi', 'set', { en: 'Yesterday 23:10', nl: 'Gisteren 23:10' }),
      s('s4', 'Jens Wouters', 'FloorStaff', 'jwouters', 'locked', { en: '19:01 · Host Stand 1', nl: '19:01 · Host Stand 1' }),
      s('s5', 'Lotte Maes', 'FloorStaff', 'lmaes', 'none', { en: 'Never', nl: 'Nooit' }),
      s('s6', 'Bram Peeters', 'FloorStaff', 'bpeeters', 'set', { en: 'Sun 30 Aug', nl: 'zo 30 aug' }, false)
    ];
  }
  function conflicts() {
    return [
      { id: 'c1', kind: 'overlap', entity: 'Reservation', table: 'M12', detected: '19:02', device: 'Host Stand 2',
        title: { en: 'M12 · overlapping bookings', nl: 'M12 · overlappende reservaties' },
        reason: { en: 'Table already booked for an overlapping time (19:00–20:30).', nl: 'Tafel is al geboekt voor een overlappend tijdslot (19:00–20:30).' },
        submitted: { who: 'Emma D. · Host Stand 2 · 18:41', name: 'Willems, Karim', line: { en: 'Party of 5 · 19:15 · M12', nl: '5 personen · 19:15 · M12' }, note: 'Asked for a quiet corner' },
        server: { who: 'Sam V. · website · 18:20', name: 'Vandenberghe, Elke', line: { en: 'Party of 4 · 19:00 · M12', nl: '4 personen · 19:00 · M12' }, note: 'Regular guest' },
        party: 5, canReassign: true },
      { id: 'c2', kind: 'capacity', entity: 'Reservation', table: 'P6', detected: '18:56', device: 'Bar Tablet',
        title: { en: 'P6 · party too large', nl: 'P6 · gezelschap te groot' },
        reason: { en: 'Party of 6 exceeds P6 (2–4 seats), and P6 is not in a table group.', nl: 'Gezelschap van 6 is te groot voor P6 (2–4 plaatsen), en P6 zit niet in een tafelcombinatie.' },
        submitted: { who: 'Jens W. · Bar Tablet · 18:37', name: 'Maes, Joris', line: { en: 'Party of 6 · 20:30 · P6', nl: '6 personen · 20:30 · P6' }, note: '' },
        server: { who: 'Tables module', name: 'P6', line: { en: 'Seats 2–4 · Patio · combinable', nl: '2–4 plaatsen · Terras · combineerbaar' }, note: '' },
        party: 6, canReassign: true },
      { id: 'c3', kind: 'status', entity: 'Table', table: 'B3', detected: '18:53', device: 'Bar Tablet',
        title: { en: 'B3 · status changed on server', nl: 'B3 · status gewijzigd op server' },
        reason: { en: 'B3 was blocked on the server after this offline change was made.', nl: 'B3 werd op de server geblokkeerd nadat deze offline wijziging gebeurde.' },
        submitted: { who: 'Jens W. · Bar Tablet · 18:44', name: 'B3', line: { en: 'Blocked → Available', nl: 'Geblokkeerd → Vrij' }, note: '' },
        server: { who: 'Sam V. · website · 18:30', name: 'B3', line: { en: 'Available → Blocked', nl: 'Vrij → Geblokkeerd' }, note: 'Wobbly leg, waiting for repair' },
        party: 0, canReassign: false }
    ];
  }
  function devices() {
    return [
      { id: 'd1', name: 'Host Stand 1', state: 'online', pairedBy: 'Sam V.', pairedAt: { en: '2 Aug 2026', nl: '2 aug 2026' }, lastSeen: { en: 'Now', nl: 'Nu' }, pending: 0, active: true },
      { id: 'd2', name: 'Host Stand 2', state: 'online', pairedBy: 'Sam V.', pairedAt: { en: '2 Aug 2026', nl: '2 aug 2026' }, lastSeen: { en: '1 min ago', nl: '1 min geleden' }, pending: 0, active: true },
      { id: 'd3', name: 'Bar Tablet', state: 'offline', pairedBy: 'Noor E.', pairedAt: { en: '11 Sep 2026', nl: '11 sep 2026' }, lastSeen: { en: '18:40', nl: '18:40' }, pending: 3, grace: '06:40', active: true },
      { id: 'd4', name: 'Manager Office iPad', state: 'off', pairedBy: 'Sam V.', pairedAt: { en: '10 Jul 2026', nl: '10 jul 2026' }, lastSeen: { en: 'Sun 20 Sep', nl: 'zo 20 sep' }, pending: 0, active: false }
    ];
  }
  function hours() {
    const L = (s, e) => ({ s, e });
    return [
      { d: 0, date: 21, closed: true, lunch: null, dinner: null },
      { d: 1, date: 22, closed: false, lunch: null, dinner: L('18:00', '22:30') },
      { d: 2, date: 23, closed: false, lunch: L('12:00', '14:30'), dinner: L('17:30', '22:30'), today: true },
      { d: 3, date: 24, closed: false, lunch: L('12:00', '14:30'), dinner: L('17:30', '22:30') },
      { d: 4, date: 25, closed: false, lunch: L('12:00', '14:30'), dinner: L('17:30', '23:00') },
      { d: 5, date: 26, closed: false, lunch: L('12:00', '15:00'), dinner: L('17:30', '23:00') },
      { d: 6, date: 27, closed: false, lunch: L('12:00', '15:30'), dinner: null }
    ];
  }
  const closures = [
    { date: { en: 'Mon 5 Oct', nl: 'ma 5 okt' }, label: { en: 'Closed · staff training', nl: 'Gesloten · personeelsopleiding' }, closed: true },
    { date: { en: 'Thu 24 Dec', nl: 'do 24 dec' }, label: { en: 'Dinner only · 17:00–21:00', nl: 'Enkel avond · 17:00–21:00' }, closed: false },
    { date: { en: 'Fri 25 Dec', nl: 'vr 25 dec' }, label: { en: 'Closed', nl: 'Gesloten' }, closed: true }
  ];
  return { T, DAYS, MON, secNames, reservations, tables, staff, conflicts, devices, hours, closures, toMin, NOW, sectionOrder: ['Main Room', 'Patio', 'Bar'] };
})();
